#ifndef SAT_PREF_ROT_EDITOR_H
#define SAT_PREF_ROT_EDITOR_H 1

#include <gtk/gtk.h>
#include "rotor-conf.h"

void            sat_pref_rot_editor_run(rotor_conf_t * conf);

#endif
