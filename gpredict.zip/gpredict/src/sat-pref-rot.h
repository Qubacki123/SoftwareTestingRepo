#ifndef SAT_PREF_ROT_H
#define SAT_PREF_ROT_H 1

GtkWidget      *sat_pref_rot_create(void);
void            sat_pref_rot_cancel(void);
void            sat_pref_rot_ok(void);

#endif
