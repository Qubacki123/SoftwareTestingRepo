#ifndef GUI_H
#define GUI_H 1

#include <gtk/gtk.h>

GtkWidget *gui_create(GtkWidget *window);

#endif
