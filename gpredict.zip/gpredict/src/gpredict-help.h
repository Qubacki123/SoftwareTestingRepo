#ifndef GPREDICT_HELP_H
#define GPREDICT_HELP_H 1

void            gpredict_help_show_txt(const gchar * filename);

#endif
