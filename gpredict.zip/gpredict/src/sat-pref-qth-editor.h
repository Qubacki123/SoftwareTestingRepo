#ifndef SAT_PREF_QTH_EDITOR_H
#define SAT_PREF_QTH_EDITOR_H 1

#include <gtk/gtk.h>

void            sat_pref_qth_editor_run(GtkTreeView * treeview, gboolean new);

#endif
