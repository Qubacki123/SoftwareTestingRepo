#ifndef SAT_PREF_MULTI_PASS_H
#define SAT_PREF_MULTI_PASS_H 1

GtkWidget      *sat_pref_multi_pass_create(void);
void            sat_pref_multi_pass_cancel(void);
void            sat_pref_multi_pass_ok(void);

#endif
