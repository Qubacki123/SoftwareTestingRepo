#ifndef SAT_PREF_DEBUG_H
#define SAT_PREF_DEBUG_H 1

GtkWidget      *sat_pref_debug_create(void);
void            sat_pref_debug_cancel(void);
void            sat_pref_debug_ok(void);

#endif
