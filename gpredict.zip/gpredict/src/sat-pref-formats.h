#ifndef SAT_PREF_FORMATS_H
#define SAT_PREF_FORMATS_H 1

GtkWidget      *sat_pref_formats_create(void);
void            sat_pref_formats_cancel(void);
void            sat_pref_formats_ok(void);

#endif
