#ifndef SAT_PREF_SINGLE_PASS_H
#define SAT_PREF_SINGLE_PASS_H 1

GtkWidget      *sat_pref_single_pass_create(void);
void            sat_pref_single_pass_cancel(void);
void            sat_pref_single_pass_ok(void);

#endif
