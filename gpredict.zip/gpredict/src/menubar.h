#ifndef MENUBAR_H
#define MENUBAR_H 1

GtkWidget      *menubar_create(GtkWidget * window);

#endif
