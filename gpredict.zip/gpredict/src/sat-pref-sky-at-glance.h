#ifndef SAT_PREF_SKY_AT_GLANCE_H
#define SAT_PREF_SKY_AT_GLANCE_H 1

GtkWidget      *sat_pref_sky_at_glance_create(void);
void            sat_pref_sky_at_glance_cancel(void);
void            sat_pref_sky_at_glance_ok(void);

#endif
