#ifndef SAT_PREF_CONDITIONS_H
#define SAT_PREF_CONDITIONS_H 1

GtkWidget      *sat_pref_conditions_create(void);
void            sat_pref_conditions_cancel(void);
void            sat_pref_conditions_ok(void);

#endif
