#ifndef SAT_PREF_TLE_H
#define SAT_PREF_TLE_H 1

GtkWidget      *sat_pref_tle_create(void);
void            sat_pref_tle_cancel(void);
void            sat_pref_tle_ok(void);

#endif
