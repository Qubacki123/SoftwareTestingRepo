/* log file browser */
#ifndef SAT_LOG_BROWSER_H
#define SAT_LOG_BROWSER_H 1

void            sat_log_browser_open(void);

#endif
