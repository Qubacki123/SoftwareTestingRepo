#ifndef SAT_PREF_H
#define SAT_PREF_H 1

void            sat_pref_run(void);

#endif
