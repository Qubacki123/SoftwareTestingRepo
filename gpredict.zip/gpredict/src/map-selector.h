#ifndef MAP_SELECTOR_H
#define MAP_SELECTOR_H 1

gchar          *select_map(const gchar * curmap);

#endif
