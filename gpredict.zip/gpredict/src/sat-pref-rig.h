#ifndef SAT_PREF_RIG_H
#define SAT_PREF_RIG_H 1

GtkWidget      *sat_pref_rig_create(void);
void            sat_pref_rig_cancel(void);
void            sat_pref_rig_ok(void);

#endif
