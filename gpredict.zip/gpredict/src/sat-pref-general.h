#ifndef SAT_PREF_GENERAL_H
#define SAT_PREF_GENERAL_H 1

GtkWidget      *sat_pref_general_create(void);
void            sat_pref_general_cancel(void);
void            sat_pref_general_ok(void);

#endif
