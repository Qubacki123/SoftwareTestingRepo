#ifndef ABOUT_H
#define ABOUT_H 1

void about_dialog_create(void);

#endif
